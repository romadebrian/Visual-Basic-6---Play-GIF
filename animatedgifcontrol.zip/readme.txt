Here is a gif animation control written in VB.  I used code from various sources, modify and fix them.
You can use my freely.  I am not responsible for any mishappening using my code.
For any suggestion or bug fix or improvement, please send e-mail to lam_sam@yahoo.com